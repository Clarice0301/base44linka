import { Toaster } from "@/components/ui/toaster"
import { QueryClientProvider } from '@tanstack/react-query'
import { queryClientInstance } from '@/lib/query-client'
import { BrowserRouter as Router, Navigate, Route, Routes } from 'react-router-dom';
import PageNotFound from './lib/PageNotFound';
import ProtectedRoute from '@/components/ProtectedRoute';
import { AuthProvider, useAuth } from '@/lib/AuthContext';
import UserNotRegisteredError from '@/components/UserNotRegisteredError';
import ScrollToTop from './components/ScrollToTop';
// Add page imports here
import { LinkaProvider } from '@/context/LinkaContext';
import PhoneFrame from '@/components/linka/PhoneFrame';
import Inicio from '@/pages/Inicio';
import Vagas from '@/pages/Vagas';
import Cursos from '@/pages/Cursos';
import Candidaturas from '@/pages/Candidaturas';
import Perfil from '@/pages/Perfil';
import Chat from '@/pages/Chat';
import Recrutador from '@/pages/Recrutador';
import Login from '@/pages/Login';
import Register from '@/pages/Register';
import ForgotPassword from '@/pages/ForgotPassword';
import ResetPassword from '@/pages/ResetPassword';
import Testes from '@/pages/Testes';
import Preferencias from '@/pages/Preferencias';
import AdminCertificados from '@/pages/AdminCertificados';
import Empresa from '@/pages/Empresa';
import CompanyRoute from '@/components/linka/CompanyRoute';
import EmpresaLogin from '@/pages/EmpresaLogin';
import GestaoEmpresa from '@/pages/GestaoEmpresa';

const AuthenticatedApp = () => {
  const { isLoadingAuth, isLoadingPublicSettings, authError, navigateToLogin } = useAuth();

  // Show loading spinner while checking app public settings or auth
  if (isLoadingPublicSettings || isLoadingAuth) {
    return (
      <div className="fixed inset-0 flex items-center justify-center">
        <div className="w-8 h-8 border-4 border-slate-200 border-t-slate-800 rounded-full animate-spin"></div>
      </div>
    );
  }

  // Handle authentication errors
  if (authError) {
    if (authError.type === 'user_not_registered') {
      return <UserNotRegisteredError />;
    } else if (authError.type === 'auth_required') {
      // Redirect to login automatically
      navigateToLogin();
      return null;
    }
  }

  // Render the main app
  return (
    <LinkaProvider>
      <Routes>
        <Route element={<ProtectedRoute unauthenticatedElement={<Navigate to="/login" replace />} />}>
        <Route element={<PhoneFrame />}>
          <Route path="/" element={<Inicio />} />
          <Route path="/vagas" element={<Vagas />} />
          <Route path="/cursos" element={<Cursos />} />
          <Route path="/candidaturas" element={<Candidaturas />} />
          <Route path="/perfil" element={<Perfil />} />
          <Route path="/chat" element={<Chat />} />
          <Route path="/chat/:id" element={<Chat />} />

          <Route path="/testes" element={<Testes />} />
          <Route path="/preferencias" element={<Preferencias />} />
          <Route path="/admin/certificados" element={<AdminCertificados />} />
          <Route element={<CompanyRoute />}>
            <Route path="/empresa" element={<Empresa />} />
            <Route path="/empresa/gestao" element={<GestaoEmpresa />} />
            <Route path="/recrutador" element={<Recrutador />} />
          </Route>
        </Route>
        </Route>
        <Route path="/login" element={<Login />} />
        <Route path="/empresa/login" element={<EmpresaLogin />} />
        <Route path="/register" element={<Register />} />
        <Route path="/forgot-password" element={<ForgotPassword />} />
        <Route path="/reset-password" element={<ResetPassword />} />
        <Route path="*" element={<PageNotFound />} />
      </Routes>
    </LinkaProvider>
  );
};

function App() {

  return (
    <AuthProvider>
      <QueryClientProvider client={queryClientInstance}>
        <Router>
          <ScrollToTop />
          <AuthenticatedApp />
        </Router>
        <Toaster />
      </QueryClientProvider>
    </AuthProvider>
  )
}

export default App