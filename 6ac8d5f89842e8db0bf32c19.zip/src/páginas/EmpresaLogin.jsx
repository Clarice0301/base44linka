const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React, { useState } from "react";
import { Link } from "react-router-dom";
import { ArrowLeft, ArrowRight, Building2, Loader2, ShieldCheck } from "lucide-react";
import { Image } from "@/components/ui/image";

import GoogleIcon from "@/components/GoogleIcon";
import { loginWithMfa, continueMfa, loginWithGoogle } from "@/lib/authMfa";
import { LOGO_HEADER } from "@/lib/linka/data";

export default function EmpresaLogin() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const [needsActivation, setNeedsActivation] = useState(false);
  const [activating, setActivating] = useState(false);

  const openCompanyArea = async () => {
    const me = await db.auth.me();
    if (me?.role === "admin" || me?.account_type === "empresa") {
      window.location.href = "/empresa";
      return;
    }
    setNeedsActivation(true);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");
    setLoading(true);
    try {
      const result = await loginWithMfa(email, password);
      if (result.mfa_required) {
        await continueMfa(result, "/empresa");
        return;
      }
      await openCompanyArea();
    } catch (err) {
      setError(err?.message || "E-mail ou senha inválidos");
    } finally {
      setLoading(false);
    }
  };

  const handleGoogle = () => {
    loginWithGoogle("/empresa");
  };

  const activate = async () => {
    setActivating(true);
    setError("");
    try {
      await db.auth.updateMe({ account_type: "empresa" });
      window.location.href = "/empresa";
    } catch (err) {
      setError(err?.message || "Não foi possível ativar a conta de empresa.");
      setActivating(false);
    }
  };

  return (
    <div className="lk-auth lk-auth-company">
      <div className="lk-auth-inner">
        <div className="flex justify-center">
          <Image src={LOGO_HEADER} alt="Linka" className="lk-auth-logo" fittingType="fit" />
        </div>

        <div className="flex justify-center">
          <span className="lk-company-badge">
            <Building2 size={14} strokeWidth={2} /> Área da empresa
          </span>
        </div>

        <h1 className="lk-auth-title">Acesso da empresa</h1>
        <p className="lk-auth-sub">
          Lance vagas, acompanhe as candidaturas e publique novidades para os talentos da rede.
        </p>

        <div className="lk-auth-card">
          {error ? <div className="lk-auth-error">{error}</div> : null}

          {needsActivation ? (
            <div>
              <h2 className="lk-auth-cardtitle">Esta conta ainda é de candidato</h2>
              <p className="lk-auth-cardsub">
                Ative o perfil de empresa desta conta para cadastrar sua empresa e gerenciar vagas e
                candidaturas. A área do candidato continua disponível em outro acesso.
              </p>
              <button type="button" className="lk-auth-submit mt-4" onClick={activate} disabled={activating}>
                {activating ? (
                  <Loader2 className="h-5 w-5 animate-spin" aria-hidden="true" />
                ) : (
                  <>
                    <ShieldCheck size={18} strokeWidth={2} /> Ativar conta de empresa
                  </>
                )}
              </button>
            </div>
          ) : (
            <>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                  <label htmlFor="company-email" className="lk-auth-label">
                    E-mail corporativo
                  </label>
                  <input
                    id="company-email"
                    type="email"
                    autoComplete="email"
                    autoFocus
                    className="lk-auth-input"
                    placeholder="voce@suaempresa.com"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    required
                  />
                </div>

                <div>
                  <div className="mb-2 flex items-center justify-between">
                    <label htmlFor="company-password" className="lk-auth-label is-tight">
                      Senha
                    </label>
                    <Link to="/forgot-password" className="lk-auth-mini">
                      Esqueci minha senha
                    </Link>
                  </div>
                  <input
                    id="company-password"
                    type="password"
                    autoComplete="current-password"
                    className="lk-auth-input"
                    placeholder="Pelo menos 6 caracteres"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    required
                  />
                </div>

                <button type="submit" className="lk-auth-submit" disabled={loading}>
                  {loading ? (
                    <Loader2 className="h-5 w-5 animate-spin" aria-hidden="true" />
                  ) : (
                    <>
                      Entrar como empresa <ArrowRight size={18} strokeWidth={2} />
                    </>
                  )}
                </button>
              </form>

              <div className="lk-auth-divider">ou</div>

              <button type="button" className="lk-auth-google" onClick={handleGoogle}>
                <GoogleIcon className="h-5 w-5" /> Entrar com Google
              </button>

              <div className="lk-auth-portal">
                <strong>Primeiro acesso?</strong>
                <p>Crie sua conta no Linka e ative o perfil de empresa para começar a contratar.</p>
                <Link to="/register">Criar conta</Link>
              </div>
            </>
          )}

          <div className="lk-auth-foot">
            <Link to="/login" className="lk-auth-mini inline-flex items-center gap-1">
              <ArrowLeft size={14} strokeWidth={2} /> Sou candidato — acesso do candidato
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}