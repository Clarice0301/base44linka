const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React, { useEffect, useMemo, useState } from "react";
import { ExternalLink, Search, SearchX } from "lucide-react";

import { Chip, EmptyState, ProgressBar, ScreenTitle } from "@/components/linka/primitives";
import { useLinka } from "@/context/LinkaContext";

const PRICE_FILTERS = ["Todos", "Gratuitos", "Pagos"];
const HOURS_FILTERS = ["Todas", "Até 5h", "6h a 20h", "Mais de 20h"];

const CERT_STATUS = {
  pending: { label: "Em análise", tone: "sun" },
  approved: { label: "Aprovado", tone: "teal" },
  rejected: { label: "Não aprovado", tone: "blue" },
};

function openSigned(uri) {
  return db.integrations.Core.CreateFileSignedUrl({ file_uri: uri }).then((res) =>
    window.open(res.signed_url, "_blank")
  );
}

export default function Cursos() {
  const { catalogCourses, courses, loading, openSheet } = useLinka();
  const [tab, setTab] = useState("catalogo");
  const [query, setQuery] = useState("");
  const [area, setArea] = useState("Todas");
  const [provider, setProvider] = useState("Todos");
  const [price, setPrice] = useState("Todos");
  const [hours, setHours] = useState("Todas");
  const [certs, setCerts] = useState([]);

  useEffect(() => {
    let ok = true;
    db.entities.Certificate.filter({}, { sort: "-created_date", limit: 50 }).then((page) => {
      if (ok) setCerts(page.items || []);
    });
    return () => {
      ok = false;
    };
  }, []);

  const areas = useMemo(() => [...new Set(catalogCourses.map((c) => c.area))].sort(), [catalogCourses]);
  const providers = useMemo(() => [...new Set(catalogCourses.map((c) => c.provider))].sort(), [catalogCourses]);

  const list = catalogCourses.filter((course) => {
    const term = query.trim().toLowerCase();
    if (term && !(`${course.title} ${(course.skills || []).join(" ")}`.toLowerCase().includes(term))) return false;
    if (area !== "Todas" && course.area !== area) return false;
    if (provider !== "Todos" && course.provider !== provider) return false;
    if (price === "Gratuitos" && !course.free) return false;
    if (price === "Pagos" && course.free) return false;
    if (hours === "Até 5h" && course.hours > 5) return false;
    if (hours === "6h a 20h" && (course.hours < 6 || course.hours > 20)) return false;
    if (hours === "Mais de 20h" && course.hours <= 20) return false;
    return true;
  });

  return (
    <div>
      <ScreenTitle
        title="Cursos com certificado"
        subtitle="Somente catálogos oficiais, verificados e com certificado. O curso abre no site do provedor."
      />

      <div className="lk-pills">
        <button type="button" className={`lk-pill${tab === "catalogo" ? " is-on" : ""}`} onClick={() => setTab("catalogo")}>
          Catálogo oficial ({catalogCourses.length})
        </button>
        <button type="button" className={`lk-pill${tab === "meus" ? " is-on" : ""}`} onClick={() => setTab("meus")}>
          Cursos do Linka ({courses.length})
        </button>
      </div>

      {tab === "catalogo" ? (
        <>
          <div className="relative mt-3">
            <Search size={18} strokeWidth={1.8} style={{ position: "absolute", left: 14, top: 16, color: "var(--ink-2)" }} />
            <input
              className="lk-input"
              style={{ paddingLeft: 42 }}
              placeholder="Buscar curso ou habilidade"
              value={query}
              onChange={(event) => setQuery(event.target.value)}
              aria-label="Buscar cursos"
            />
          </div>

          <div className="mt-2 grid grid-cols-2 gap-2">
            <select className="lk-input" value={area} onChange={(event) => setArea(event.target.value)} aria-label="Filtrar por área">
              <option>Todas</option>
              {areas.map((item) => (
                <option key={item}>{item}</option>
              ))}
            </select>
            <select className="lk-input" value={provider} onChange={(event) => setProvider(event.target.value)} aria-label="Filtrar por provedor">
              <option>Todos</option>
              {providers.map((item) => (
                <option key={item}>{item}</option>
              ))}
            </select>
            <select className="lk-input" value={price} onChange={(event) => setPrice(event.target.value)} aria-label="Filtrar por preço">
              {PRICE_FILTERS.map((item) => (
                <option key={item}>{item}</option>
              ))}
            </select>
            <select className="lk-input" value={hours} onChange={(event) => setHours(event.target.value)} aria-label="Filtrar por carga horária">
              {HOURS_FILTERS.map((item) => (
                <option key={item}>{item}</option>
              ))}
            </select>
          </div>

          <div className="mt-4 space-y-3">
            {loading ? <p className="lk-sub">Carregando cursos...</p> : null}
            {list.map((course) => (
              <button key={course.id} type="button" className="lk-card w-full text-left" onClick={() => openSheet("catalogCourse", course.id)}>
                <div className="flex items-start justify-between gap-3">
                  <div className="min-w-0">
                    <h3 className="lk-card-title">{course.title}</h3>
                    <p className="lk-card-sub">{course.provider}</p>
                  </div>
                  <ExternalLink size={17} strokeWidth={1.8} style={{ color: "var(--ink-2)", flexShrink: 0 }} />
                </div>
                <div className="mt-3 flex flex-wrap gap-2">
                  <Chip tone="blue">{course.area}</Chip>
                  <Chip tone="blue">{course.level}</Chip>
                  <Chip tone="teal">{course.hours}h</Chip>
                  <Chip tone={course.free ? "teal" : "sun"}>{course.free ? "Gratuito" : "Pago"}</Chip>
                  <Chip tone="sun">Verificado em {course.verified_at}</Chip>
                </div>
              </button>
            ))}
            {!loading && !list.length ? (
              <EmptyState
                icon={SearchX}
                title="Nada por aqui"
                text="Nenhum curso com esses filtros. Tente outra área ou provedor."
                action={
                  <button
                    type="button"
                    className="lk-btn lk-btn-soft lk-btn-sm"
                    onClick={() => {
                      setQuery("");
                      setArea("Todas");
                      setProvider("Todos");
                      setPrice("Todos");
                      setHours("Todas");
                    }}
                  >
                    Limpar filtros
                  </button>
                }
              />
            ) : null}
          </div>
        </>
      ) : (
        <div className="mt-4 space-y-3">
          {loading ? <p className="lk-sub">Carregando...</p> : null}
          {courses.map((course) => {
            const done = course.lessons?.length || 0;
            return (
              <button key={course.id} type="button" className="lk-card w-full text-left" onClick={() => openSheet("course", course.id)}>
                <h3 className="lk-card-title">{course.title}</h3>
                <p className="lk-card-sub">{course.level} · {course.duration}</p>
                <div className="mt-3">
                  <ProgressBar value={Math.round((done / Math.max(1, course.lessons?.length || 3)) * 100)} />
                </div>
                <div className="mt-2 flex flex-wrap gap-2">
                  {(course.skills || []).map((skill) => (
                    <Chip key={skill} tone="blue">
                      {skill}
                    </Chip>
                  ))}
                </div>
              </button>
            );
          })}
        </div>
      )}

      <section className="mt-6">
        <p className="lk-eyebrow">Meus certificados</p>
        {!certs.length ? (
          <p className="lk-card-sub mt-2">
            Conclua um curso, envie o certificado do provedor e ele aparece aqui para aprovação.
          </p>
        ) : (
          <div className="mt-3 space-y-2">
            {certs.map((cert) => {
              const status = CERT_STATUS[cert.status] || CERT_STATUS.pending;
              return (
                <div key={cert.id} className="lk-card">
                  <div className="flex items-start justify-between gap-3">
                    <div className="min-w-0">
                      <h3 className="lk-card-title">{cert.course_title}</h3>
                      <p className="lk-card-sub">{cert.provider}</p>
                    </div>
                    <Chip tone={status.tone}>{status.label}</Chip>
                  </div>
                  {cert.status === "approved" && cert.skill ? (
                    <p className="lk-card-sub mt-2">Habilidade validada: {cert.skill}</p>
                  ) : null}
                  {cert.verification ? (
                    <p className="lk-card-sub mt-1">Código informado: {cert.verification}</p>
                  ) : null}
                  {cert.file_uri ? (
                    <button type="button" className="lk-btn lk-btn-soft lk-btn-sm mt-2" onClick={() => openSigned(cert.file_uri)}>
                      Abrir arquivo
                    </button>
                  ) : null}
                </div>
              );
            })}
          </div>
        )}
      </section>
    </div>
  );
}