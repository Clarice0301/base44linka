import React, { useEffect, useRef, useState } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";
import { ArrowLeft, MessageSquare, Send } from "lucide-react";
import { EmptyState } from "@/components/linka/primitives";
import { useLinka } from "@/context/LinkaContext";
import { formatShortDate } from "@/lib/linka/data";

function ChatList() {
  const { applications, threads } = useLinka();
  const navigate = useNavigate();

  if (!applications.length) {
    return (
      <div>
        <h1 className="lk-h1">Conversas</h1>
        <div className="mt-4">
          <EmptyState
            icon={MessageSquare}
            title="Nenhuma conversa ainda"
            text="Depois que você se candidatar, a conversa com a empresa aparece aqui."
            action={
              <button type="button" className="lk-btn lk-btn-primary" onClick={() => navigate("/vagas")}>
                Procurar vagas
              </button>
            }
          />
        </div>
      </div>
    );
  }

  return (
    <div>
      <h1 className="lk-h1">Conversas</h1>
      <p className="lk-sub">Fale direto com quem está avaliando sua candidatura.</p>

      <div className="mt-4 space-y-2">
        {applications.map((application) => {
          const thread = threads[application.id] || [];
          const last = thread[thread.length - 1];
          return (
            <Link
              key={application.id}
              to={`/chat/${application.id}`}
              className="lk-card"
              style={{ display: "flex", gap: 12, alignItems: "center" }}
            >
              <span
                className="grid place-items-center"
                style={{
                  width: 44,
                  height: 44,
                  borderRadius: 14,
                  background: "var(--tint-teal)",
                  color: "var(--teal-ink)",
                }}
              >
                <MessageSquare size={20} strokeWidth={1.8} />
              </span>
              <span className="min-w-0 flex-1">
                <strong style={{ display: "block", fontSize: 14.5, color: "var(--ink)" }}>
                  {application.company}
                </strong>
                <span className="lk-card-sub">
                  {last ? last.text : `Fale sobre a vaga de ${application.jobTitle}`}
                </span>
              </span>
            </Link>
          );
        })}
      </div>
    </div>
  );
}

function ChatThread({ applicationId }) {
  const { applications, threads, sendMessage, profile } = useLinka();
  const navigate = useNavigate();
  const [text, setText] = useState("");
  const bottomRef = useRef(null);

  const application = applications.find((item) => item.id === applicationId);
  const messages = threads[applicationId] || [];

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ block: "end" });
  }, [messages.length]);

  if (!application) {
    return (
      <div>
        <button type="button" className="lk-btn lk-btn-soft lk-btn-sm" onClick={() => navigate("/chat")}>
          <ArrowLeft size={16} strokeWidth={1.8} /> Voltar
        </button>
        <p className="lk-sub mt-4">Essa conversa não está mais disponível.</p>
      </div>
    );
  }

  const submit = () => {
    sendMessage(applicationId, text, "me");
    setText("");
  };

  return (
    <div className="flex min-h-full flex-col">
      <div className="flex items-center gap-2">
        <button
          type="button"
          className="lk-heart"
          aria-label="Voltar para as conversas"
          onClick={() => navigate("/chat")}
        >
          <ArrowLeft size={18} strokeWidth={2} />
        </button>
        <div className="min-w-0 flex-1">
          <strong style={{ display: "block", fontSize: 15, color: "var(--ink)" }}>{application.company}</strong>
          <span className="lk-card-sub">{application.jobTitle}</span>
        </div>
      </div>

      <div className="mt-4 flex flex-1 flex-col gap-2">
        {!messages.length ? (
          <p className="lk-sub">
            Diga olá para quem está avaliando sua candidatura. Uma mensagem curta e objetiva já ajuda.
          </p>
        ) : null}

        {messages.map((message) => (
          <div
            key={message.id}
            className={`lk-bubble ${message.from === "me" ? "lk-bubble-me" : "lk-bubble-company"}`}
          >
            <span>{message.text}</span>
            <span style={{ display: "block", marginTop: 4, fontSize: 10.5, opacity: 0.7 }}>
              {formatShortDate(message.at)}
            </span>
          </div>
        ))}
        <div ref={bottomRef} />
      </div>

      <div className="mt-4 flex items-end gap-2">
        <textarea
          className="lk-textarea"
          style={{ minHeight: 50, paddingTop: 14 }}
          rows={1}
          placeholder={`Mensagem como ${profile.name || "candidato(a)"}`}
          value={text}
          onChange={(event) => setText(event.target.value)}
          aria-label="Escreva sua mensagem"
        />
        <button type="button" className="lk-iconbtn" style={{ background: "var(--brand-teal)", color: "#0B2238" }} onClick={submit} aria-label="Enviar mensagem">
          <Send size={18} strokeWidth={2} />
        </button>
      </div>
    </div>
  );
}

export default function Chat() {
  const { id } = useParams();
  return id ? <ChatThread applicationId={id} /> : <ChatList />;
}