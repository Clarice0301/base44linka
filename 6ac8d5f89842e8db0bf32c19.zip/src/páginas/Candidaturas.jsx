import React from "react";
import { useNavigate } from "react-router-dom";
import { Inbox } from "lucide-react";
import ApplicationCard from "@/components/linka/ApplicationCard";
import { EmptyState, ScreenTitle } from "@/components/linka/primitives";
import { useLinka } from "@/context/LinkaContext";

export default function Candidaturas() {
  const { applications } = useLinka();
  const navigate = useNavigate();

  return (
    <div>
      <ScreenTitle
        title="Candidaturas"
        subtitle="Cada candidatura tem retorno. Nada de buraco negro."
      />

      <div className="space-y-3">
        {applications.map((application) => (
          <ApplicationCard key={application.id} application={application} />
        ))}

        {!applications.length ? (
          <EmptyState
            icon={Inbox}
            title="Nenhuma candidatura ainda"
            text="Quando você se candidatar, cada etapa aparece aqui com uma mensagem da empresa."
            action={
              <button type="button" className="lk-btn lk-btn-primary" onClick={() => navigate("/vagas")}>
                Procurar vagas
              </button>
            }
          />
        ) : null}
      </div>
    </div>
  );
}