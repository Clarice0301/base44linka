const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React, { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Award, Briefcase, Building2, Moon, RotateCcw, ShieldCheck, Sparkles, Users } from "lucide-react";

import { useLinka } from "@/context/LinkaContext";
import { THEME_OPTIONS, formatShortDate } from "@/lib/linka/data";
import ApplicationDashboard from "@/components/linka/ApplicationDashboard";
import ProfileSummary from "@/components/linka/profile/ProfileSummary";
import ProfileForm from "@/components/linka/profile/ProfileForm";

export default function Perfil() {
  const { profile, applications, lessons, courses, events, theme, setTheme, updateProfile, resetAll } = useLinka();
  const navigate = useNavigate();
  const [editing, setEditing] = useState(false);
  const [me, setMe] = useState(null);
  const [activating, setActivating] = useState(false);

  useEffect(() => {
    db.auth.me().then(setMe).catch(() => {});
  }, []);

  const isAdmin = me?.role === "admin";
  const isCompany = isAdmin || me?.account_type === "empresa";

  const completedCourses = courses.filter(
    (course) => (lessons[course.id] || []).length >= (course.lessons?.length || 3)
  ).length;

  const save = (patch) => {
    updateProfile(patch);
    setEditing(false);
  };

  const activateCompany = async () => {
    setActivating(true);
    try {
      const updated = await db.auth.updateMe({ account_type: "empresa" });
      setMe(updated);
      navigate("/empresa");
    } finally {
      setActivating(false);
    }
  };

  return (
    <div>
      {editing ? (
        <ProfileForm initial={profile} onSave={save} onCancel={() => setEditing(false)} />
      ) : (
        <ProfileSummary profile={profile} onEdit={() => setEditing(true)} />
      )}

      <div className="mt-4 grid grid-cols-3 gap-2.5">
        <div className="lk-tile">
          <b>{profile.skills.length}</b>
          <span>habilidades</span>
        </div>
        <div className="lk-tile">
          <b>{completedCourses}</b>
          <span>cursos concluídos</span>
        </div>
        <div className="lk-tile">
          <b>{applications.length}</b>
          <span>candidaturas</span>
        </div>
      </div>

      <ApplicationDashboard />

      <section className="mt-6">
        <div className="flex items-center gap-2">
          <Sparkles size={16} strokeWidth={1.8} style={{ color: "var(--ink-2)" }} />
          <p className="lk-eyebrow">Linha do tempo</p>
        </div>
        <div className="lk-card mt-3">
          {events.length ? (
            <div className="lk-timeline">
              {events.slice(0, 14).map((event) => (
                <div key={event.id} className="lk-time-item">
                  <p>{event.text}</p>
                  <time>{formatShortDate(event.at)}</time>
                </div>
              ))}
            </div>
          ) : (
            <p className="lk-card-sub">
              Sua história começa agora: candidate-se a uma vaga ou conclua uma lição para os primeiros
              registros aparecerem aqui.
            </p>
          )}
        </div>
      </section>

      <section className="mt-6">
        <div className="flex items-center gap-2">
          <Moon size={16} strokeWidth={1.8} style={{ color: "var(--ink-2)" }} />
          <p className="lk-eyebrow">Aparência</p>
        </div>
        <div className="lk-pills mt-3">
          {THEME_OPTIONS.map((option) => (
            <button
              key={option.value}
              type="button"
              className={`lk-pill${theme === option.value ? " is-on" : ""}`}
              onClick={() => setTheme(option.value)}
              aria-pressed={theme === option.value}
            >
              {option.label}
            </button>
          ))}
        </div>
      </section>

      <section className="mt-6 space-y-2">
        {isAdmin ? (
          <Link to="/admin/certificados" className="lk-card flex items-center gap-3" style={{ display: "flex" }}>
            <span
              className="grid place-items-center"
              style={{ width: 44, height: 44, borderRadius: 14, background: "var(--brand-sun)", color: "#12385D" }}
            >
              <ShieldCheck size={22} strokeWidth={1.8} />
            </span>
            <span className="flex-1">
              <strong style={{ display: "block", fontSize: 14.5, color: "var(--ink)" }}>Revisar certificados</strong>
              <span className="lk-card-sub">Aprove ou recuse certificados enviados.</span>
            </span>
          </Link>
        ) : null}

        {isCompany ? (
          <>
            <Link to="/empresa" className="lk-card flex items-center gap-3" style={{ display: "flex" }}>
              <span
                className="grid place-items-center"
                style={{ width: 44, height: 44, borderRadius: 14, background: "var(--brand-sun)", color: "#12385D" }}
              >
                <Building2 size={22} strokeWidth={1.8} />
              </span>
              <span className="flex-1">
                <strong style={{ display: "block", fontSize: 14.5, color: "var(--ink)" }}>Minha empresa</strong>
                <span className="lk-card-sub">Logo e dados da empresa que está contratando.</span>
              </span>
            </Link>

            <Link to="/recrutador" className="lk-card flex items-center gap-3" style={{ display: "flex" }}>
              <span
                className="grid place-items-center"
                style={{ width: 44, height: 44, borderRadius: 14, background: "var(--brand-navy)", color: "#fff" }}
              >
                <Users size={22} strokeWidth={1.8} />
              </span>
              <span className="flex-1">
                <strong style={{ display: "block", fontSize: 14.5, color: "var(--ink)" }}>Painel de candidaturas</strong>
                <span className="lk-card-sub">Veja quem se candidatou e responda cada pessoa.</span>
              </span>
              <Briefcase size={18} strokeWidth={1.8} style={{ color: "var(--ink-2)" }} />
            </Link>

            <Link to="/empresa/gestao" className="lk-card flex items-center gap-3" style={{ display: "flex" }}>
              <span
                className="grid place-items-center"
                style={{ width: 44, height: 44, borderRadius: 14, background: "var(--brand-teal)", color: "#fff" }}
              >
                <Sparkles size={22} strokeWidth={1.8} />
              </span>
              <span className="flex-1">
                <strong style={{ display: "block", fontSize: 14.5, color: "var(--ink)" }}>Gerir vagas e novidades</strong>
                <span className="lk-card-sub">Lance vagas e publique novidades da empresa.</span>
              </span>
            </Link>
          </>
        ) : me ? (
          <div className="lk-card">
            <p className="lk-eyebrow">Para empresas</p>
            <p className="lk-card-sub">
              É recrutador? Ative a conta de empresa para cadastrar sua empresa e acompanhar candidaturas.
              A área da empresa fica separada da área do candidato.
            </p>
            <button
              type="button"
              className="lk-btn lk-btn-soft lk-btn-sm mt-3"
              onClick={activateCompany}
              disabled={activating}
            >
              <Building2 size={16} strokeWidth={1.9} /> {activating ? "Ativando..." : "Criar conta de empresa"}
            </button>
          </div>
        ) : null}

        <Link to="/chat" className="lk-card flex items-center gap-3" style={{ display: "flex" }}>
          <span
            className="grid place-items-center"
            style={{ width: 44, height: 44, borderRadius: 14, background: "var(--brand-teal)", color: "#fff" }}
          >
            <Award size={22} strokeWidth={1.8} />
          </span>
          <span className="flex-1">
            <strong style={{ display: "block", fontSize: 14.5, color: "var(--ink)" }}>Conversas</strong>
            <span className="lk-card-sub">Fale com as empresas das suas candidaturas.</span>
          </span>
        </Link>

        <button type="button" className="lk-btn lk-btn-soft lk-btn-sm" onClick={resetAll}>
          <RotateCcw size={16} strokeWidth={1.8} /> Apagar meus dados deste aparelho
        </button>
      </section>
    </div>
  );
}