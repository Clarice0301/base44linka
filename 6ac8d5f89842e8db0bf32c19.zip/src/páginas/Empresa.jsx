const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React, { useEffect, useState } from "react";

import { ScreenTitle } from "@/components/linka/primitives";
import { useLinka } from "@/context/LinkaContext";
import CompanyForm from "@/components/linka/company/CompanyForm";
import CompanyProfile from "@/components/linka/company/CompanyProfile";

export default function Empresa() {
  const { notify } = useLinka();
  const [company, setCompany] = useState(null);
  const [loading, setLoading] = useState(true);
  const [editing, setEditing] = useState(false);

  useEffect(() => {
    let alive = true;
    (async () => {
      const me = await db.auth.me();
      const page = await db.entities.Company.filter({ created_by_id: me.id }, { limit: 1 });
      if (!alive) return;
      setCompany(page.items?.[0] || null);
      setEditing(!page.items?.[0]);
      setLoading(false);
    })();
    return () => {
      alive = false;
    };
  }, []);

  const handleSaved = (saved) => {
    setCompany(saved);
    setEditing(false);
    notify("Empresa salva.", "O logo e os dados já estão no seu perfil de empresa.");
  };

  return (
    <div>
      <ScreenTitle
        title="Minha empresa"
        subtitle="Cadastre o logo e os dados da empresa que está contratando pelo Linka."
      />

      {loading ? (
        <div className="lk-card" style={{ textAlign: "center" }}>
          <p className="lk-card-sub">Carregando os dados da empresa...</p>
        </div>
      ) : editing ? (
        <CompanyForm
          initial={company}
          onSaved={handleSaved}
          onCancel={company ? () => setEditing(false) : null}
        />
      ) : (
        <CompanyProfile company={company} onEdit={() => setEditing(true)} />
      )}
    </div>
  );
}