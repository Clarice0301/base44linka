const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React, { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { ArrowRight, Lightbulb, Sparkles } from "lucide-react";

import JobCard from "@/components/linka/JobCard";
import CareerGoals from "@/components/linka/home/CareerGoals";
import NewsFeed from "@/components/linka/home/NewsFeed";
import FollowCompanies from "@/components/linka/home/FollowCompanies";
import { Chip } from "@/components/linka/primitives";
import { useLinka } from "@/context/LinkaContext";
import { STAGES, WORKFLOW } from "@/lib/linka/data";
import { validatedMap } from "@/lib/linka/match";

const TIPS = [
  "Complete 'O que eu busco': o match usa seus critérios para ordenar as vagas.",
  "Habilidades validadas pesam mais. Faça um teste na aba Testes.",
  "Um certificado enviado vale mais que uma habilidade só declarada.",
  "Confira a jornada da vaga: cada etapa tem prazo garantido.",
  "Revise seu título profissional: é a primeira coisa que a empresa lê.",
];

function readTestResults() {
  try {
    return JSON.parse(localStorage.getItem("lk-test-results")) || {};
  } catch {
    return {};
  }
}

function readFollowing() {
  try {
    return JSON.parse(localStorage.getItem("lk-following")) || [];
  } catch {
    return [];
  }
}

export default function Inicio() {
  const { profile, jobs, courses, catalogCourses, applications, lessons, preferences, rejected, matchFor, openSheet, loading } = useLinka();
  const navigate = useNavigate();
  const [certs, setCerts] = useState([]);

  useEffect(() => {
    let ok = true;
    db.entities.Certificate.filter({}, { limit: 50 }).then((page) => {
      if (ok) setCerts(page.items || []);
    });
    return () => {
      ok = false;
    };
  }, []);

  const certSkills = certs.filter((cert) => cert.status !== "rejected").map((cert) => cert.skill).filter(Boolean);
  const validated = validatedMap(profile, certSkills);
  const testResults = readTestResults();
  const doneTests = Object.keys(testResults).length;

  const appliedIds = new Set(applications.map((item) => item.jobId));
  const rejectedIds = new Set((rejected || []).map((item) => item.jobId));
  const ranked = jobs
    .filter((job) => !appliedIds.has(job.id) && !rejectedIds.has(job.id))
    .sort((a, b) => matchFor(b) - matchFor(a));
  const best = ranked[0];
  const top = ranked.slice(0, 2);

  const inProgress = courses.filter((course) => {
    const done = (lessons[course.id] || []).length;
    return done > 0 && done < (course.lessons?.length || 3);
  }).length;

  const missing = [...new Set(jobs.flatMap((job) => job.requirements || []).filter((skill) => !profile.skills.includes(skill)))];
  const courseRecs = catalogCourses
    .filter((course) => (course.skills || []).some((skill) => missing.includes(skill)))
    .slice(0, 3);
  const recs = courseRecs.length ? courseRecs : catalogCourses.slice(0, 3);

  const tip = TIPS[new Date().getDate() % TIPS.length];

  return (
    <div>
      <h1 className="lk-h1">Olá! Vamos conectar você ao seu próximo passo.</h1>

      <section
        className="mt-4"
        style={{ background: "var(--brand-navy)", borderRadius: 22, padding: 18, color: "#FFFFFF" }}
      >
        <p className="lk-eyebrow" style={{ color: "rgba(255,255,255,0.72)" }}>
          Seu próximo passo
        </p>
        {best ? (
          <>
            <h2 style={{ marginTop: 8, fontSize: 16.5, fontWeight: 600, lineHeight: 1.4 }}>
              Você já tem {matchFor(best)}% de match com {best.title} na {best.company}. Que tal se candidatar?
            </h2>
            <button
              type="button"
              className="lk-btn lk-btn-primary mt-4"
              onClick={() => openSheet("job", best.id)}
            >
              Ver vaga <ArrowRight size={16} strokeWidth={2} />
            </button>
          </>
        ) : (
          <>
            <h2 style={{ marginTop: 8, fontSize: 16.5, fontWeight: 600, lineHeight: 1.4 }}>
              {applications.length
                ? "Suas candidaturas já estão caminhando. Um curso novo aumenta seu match com as próximas vagas."
                : "Sua lista de vagas está carregando. Enquanto isso, que tal somar uma habilidade nova?"}
            </h2>
            <button type="button" className="lk-btn lk-btn-primary mt-4" onClick={() => navigate("/cursos")}>
              Ver cursos <ArrowRight size={16} strokeWidth={2} />
            </button>
          </>
        )}
      </section>

      <div className="mt-4 grid grid-cols-2 gap-2.5">
        <div className="lk-tile">
          <b>{Object.keys(validated).length}</b>
          <span>habilidades validadas</span>
        </div>
        <div className="lk-tile">
          <b>{certs.length}</b>
          <span>certificados</span>
        </div>
        <div className="lk-tile">
          <b>{applications.filter((item) => item.stage < 3).length}</b>
          <span>candidaturas ativas</span>
        </div>
        <div className="lk-tile">
          <b>{readFollowing().length}</b>
          <span>empresas seguidas</span>
        </div>
      </div>

      <div className="mt-3 grid grid-cols-2 gap-2.5">
        <Link to="/preferencias" className="lk-card">
          <strong style={{ fontSize: 14, color: "var(--ink)", display: "block" }}>O que eu busco</strong>
          <p className="lk-card-sub">{preferences ? "Preferências definidas" : "Defina cargos, salário e modelo"}</p>
        </Link>
        <Link to="/testes" className="lk-card">
          <strong style={{ fontSize: 14, color: "var(--ink)", display: "block" }}>Testes</strong>
          <p className="lk-card-sub">{doneTests ? `${doneTests} teste(s) feitos` : "Valide habilidades com um teste"}</p>
        </Link>
      </div>

      {applications.length ? (
        <section className="mt-6">
          <div className="flex items-center justify-between">
            <p className="lk-eyebrow">Candidaturas ativas</p>
            <Link to="/candidaturas" className="lk-auth-mini">
              Ver todas
            </Link>
          </div>
          <div className="mt-3 space-y-2">
            {applications.slice(0, 3).map((application) => (
              <div key={application.id} className="lk-card flex items-center justify-between gap-3">
                <div className="min-w-0">
                  <strong style={{ fontSize: 13.5, color: "var(--ink)", display: "block" }}>{application.jobTitle}</strong>
                  <span className="lk-card-sub">{application.company}</span>
                </div>
                <Chip tone="sun">{STAGES[application.stage]}</Chip>
              </div>
            ))}
          </div>
        </section>
      ) : null}

      <section className="mt-6">
        <p className="lk-eyebrow">Vagas com mais match</p>
        <div className="mt-3 space-y-3">
          {loading ? <p className="lk-sub">Carregando vagas...</p> : null}
          {!loading && !top.length ? (
            <p className="lk-sub">Você já se candidatou a todas as vagas com match alto. Veja a aba Vagas.</p>
          ) : null}
          {top.map((job) => (
            <JobCard key={job.id} job={job} />
          ))}
        </div>
      </section>

      <section className="mt-6">
        <p className="lk-eyebrow">Cursos recomendados para você</p>
        <div className="mt-3 space-y-2">
          {loading ? <p className="lk-sub">Carregando cursos...</p> : null}
          {recs.map((course) => (
            <button key={course.id} type="button" className="lk-card w-full text-left" onClick={() => openSheet("catalogCourse", course.id)}>
              <strong style={{ fontSize: 14, color: "var(--ink)", display: "block" }}>{course.title}</strong>
              <div className="mt-2 flex flex-wrap gap-2">
                <Chip tone="blue">{course.provider}</Chip>
                <Chip tone="teal">{course.hours}h</Chip>
                <Chip tone={course.free ? "teal" : "sun"}>{course.free ? "Gratuito" : "Pago"}</Chip>
              </div>
            </button>
          ))}
        </div>
      </section>

      <div className="mt-6 space-y-3">
        <FollowCompanies />
        <CareerGoals />
        <NewsFeed />
      </div>

      <section
        className="mt-6"
        style={{
          background: "var(--tint-sun)",
          borderRadius: 22,
          padding: 16,
          display: "flex",
          gap: 12,
        }}
      >
        <span style={{ color: "var(--sun-ink)" }}>
          <Lightbulb size={22} strokeWidth={1.8} />
        </span>
        <div>
          <strong style={{ fontSize: 14.5, color: "var(--sun-ink)" }}>Dica do dia</strong>
          <p style={{ fontSize: 13.5, lineHeight: 1.5, color: "var(--sun-ink)" }}>{tip}</p>
        </div>
      </section>

      <section className="mt-6">
        <div className="flex items-center justify-between">
          <p className="lk-eyebrow">Como o Linka funciona</p>
          <Sparkles size={16} strokeWidth={1.8} style={{ color: "var(--ink-2)" }} />
        </div>
        <div className="mt-3 space-y-2">
          {WORKFLOW.map((item) => (
            <div key={item.n} className="lk-card flex items-start gap-3">
              <span className="lk-num">{item.n}</span>
              <div>
                <strong style={{ fontSize: 14.5, color: "var(--ink)" }}>{item.title}</strong>
                <p className="lk-card-sub">{item.text}</p>
              </div>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}