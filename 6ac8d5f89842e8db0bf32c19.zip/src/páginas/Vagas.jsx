import React, { useState } from "react";
import { Search, SearchX } from "lucide-react";
import JobCard from "@/components/linka/JobCard";
import { EmptyState, ScreenTitle } from "@/components/linka/primitives";
import { useLinka } from "@/context/LinkaContext";
import { WORK_FILTERS } from "@/lib/linka/data";

export default function Vagas() {
  const { jobs, saved, loading } = useLinka();
  const [query, setQuery] = useState("");
  const [filter, setFilter] = useState("Todas");

  const term = query.trim().toLowerCase();
  const list = jobs.filter((job) => {
    if (filter === "Salvas" && !saved.includes(job.id)) return false;
    if (["Remoto", "Híbrido", "Presencial"].includes(filter) && job.work_model !== filter) return false;
    if (!term) return true;
    return (
      job.title.toLowerCase().includes(term) || job.company.toLowerCase().includes(term)
    );
  });

  return (
    <div>
      <ScreenTitle
        title="Oportunidades para você"
        subtitle="Toda vaga mostra o salário e o orçamento confirmado. Sem surpresas no meio do caminho."
      />

      <div className="relative">
        <Search
          size={18}
          strokeWidth={1.8}
          style={{ position: "absolute", left: 14, top: 16, color: "var(--ink-2)" }}
        />
        <input
          className="lk-input"
          style={{ paddingLeft: 42 }}
          placeholder="Buscar por cargo ou empresa"
          value={query}
          onChange={(event) => setQuery(event.target.value)}
          aria-label="Buscar vagas"
        />
      </div>

      <div className="lk-pills mt-3">
        {WORK_FILTERS.map((option) => (
          <button
            key={option}
            type="button"
            className={`lk-pill${filter === option ? " is-on" : ""}`}
            onClick={() => setFilter(option)}
            aria-pressed={filter === option}
          >
            {option}
          </button>
        ))}
      </div>

      <div className="mt-4 space-y-3">
        {loading ? <p className="lk-sub">Carregando vagas...</p> : null}
        {list.map((job) => (
          <JobCard key={job.id} job={job} />
        ))}
        {!loading && !list.length ? (
          <EmptyState
            icon={SearchX}
            title="Nada por aqui"
            text="Não encontramos vagas com essa busca. Tente outro cargo, outra empresa ou mude o filtro."
            action={
              <button
                type="button"
                className="lk-btn lk-btn-soft lk-btn-sm"
                onClick={() => {
                  setQuery("");
                  setFilter("Todas");
                }}
              >
                Limpar busca
              </button>
            }
          />
        ) : null}
      </div>
    </div>
  );
}