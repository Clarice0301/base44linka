const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React, { useEffect, useState } from "react";
import { Check, ShieldCheck, X } from "lucide-react";

import { Chip, EmptyState, ScreenTitle } from "@/components/linka/primitives";
import { useLinka } from "@/context/LinkaContext";

function openSigned(uri) {
  return db.integrations.Core.CreateFileSignedUrl({ file_uri: uri }).then((res) =>
    window.open(res.signed_url, "_blank")
  );
}

export default function AdminCertificados() {
  const { notify } = useLinka();
  const [isAdmin, setIsAdmin] = useState(false);
  const [checked, setChecked] = useState(false);
  const [items, setItems] = useState([]);

  const load = async () => {
    const user = await db.auth.me().catch(() => null);
    setIsAdmin(user?.role === "admin");
    setChecked(true);
    if (user?.role === "admin") {
      const page = await db.entities.Certificate.filter({}, { sort: "-created_date", limit: 50 });
      setItems(page.items || []);
    }
  };

  useEffect(() => {
    load();
  }, []);

  const decide = async (item, status) => {
    await db.entities.Certificate.update(item.id, { status, review_note: status === "approved" ? "Aprovado pelo administrador" : "Não aprovado pelo administrador" });
    notify(status === "approved" ? "Certificado aprovado." : "Certificado recusado.", item.course_title);
    load();
  };

  if (!checked) {
    return <p className="lk-sub">Carregando...</p>;
  }

  if (!isAdmin) {
    return (
      <EmptyState
        icon={ShieldCheck}
        title="Área do administrador"
        text="Somente o administrador revisa certificados."
      />
    );
  }

  return (
    <div>
      <ScreenTitle
        title="Revisar certificados"
        subtitle="Aprove para validar a habilidade do candidato no perfil."
      />
      {!items.length ? (
        <EmptyState icon={ShieldCheck} title="Nada pendente" text="Nenhum certificado enviado ainda." />
      ) : (
        <div className="mt-4 space-y-3">
          {items.map((item) => (
            <div key={item.id} className="lk-card">
              <div className="flex items-start justify-between gap-3">
                <div className="min-w-0">
                  <h3 className="lk-card-title">{item.course_title}</h3>
                  <p className="lk-card-sub">{item.provider}</p>
                </div>
                <Chip tone={item.status === "approved" ? "teal" : item.status === "rejected" ? "blue" : "sun"}>
                  {item.status === "approved" ? "Aprovado" : item.status === "rejected" ? "Recusado" : "Pendente"}
                </Chip>
              </div>
              {item.verification ? <p className="lk-card-sub mt-1">Código: {item.verification}</p> : null}
              {item.skill ? <p className="lk-card-sub mt-1">Habilidade: {item.skill}</p> : null}
              <div className="mt-3 grid grid-cols-3 gap-2">
                <button type="button" className="lk-btn lk-btn-soft lk-btn-sm" onClick={() => item.file_uri && openSigned(item.file_uri)} disabled={!item.file_uri}>
                  Abrir
                </button>
                <button type="button" className="lk-btn lk-btn-primary lk-btn-sm" onClick={() => decide(item, "approved")}>
                  <Check size={15} strokeWidth={2.4} /> Aprovar
                </button>
                <button type="button" className="lk-btn lk-btn-soft lk-btn-sm" onClick={() => decide(item, "rejected")}>
                  <X size={15} strokeWidth={2.4} /> Recusar
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}