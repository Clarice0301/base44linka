const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React, { useState } from "react";
import { ArrowRight, Loader2 } from "lucide-react";

import { InputOTP, InputOTPGroup, InputOTPSlot } from "@/components/ui/input-otp";
import AuthShell from "@/components/linka/AuthShell";
import GoogleIcon from "@/components/GoogleIcon";
import { toast } from "@/components/ui/use-toast";
import { safeReturnTo } from "@/lib/authReturnTo";

export default function Register() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const [showOtp, setShowOtp] = useState(false);
  const [otpCode, setOtpCode] = useState("");

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");
    if (password !== confirmPassword) {
      setError("As senhas não coincidem");
      return;
    }
    setLoading(true);
    try {
      await db.auth.register({ email, password });
      setShowOtp(true);
    } catch (err) {
      setError(err.message || "Não foi possível criar a conta");
    } finally {
      setLoading(false);
    }
  };

  const handleVerify = async () => {
    setError("");
    setLoading(true);
    try {
      const result = await db.auth.verifyOtp({ email, otpCode });
      if (result?.access_token) {
        db.auth.setToken(result.access_token);
      }
      window.location.href = safeReturnTo();
    } catch (err) {
      setError(err.message || "Código de verificação inválido");
    } finally {
      setLoading(false);
    }
  };

  const handleResend = async () => {
    setError("");
    try {
      await db.auth.resendOtp(email);
      toast({
        title: "Código enviado",
        description: "Confira seu e-mail para o novo código.",
      });
    } catch (err) {
      setError(err.message || "Não foi possível reenviar o código");
    }
  };

  const handleGoogle = () => {
    db.auth.loginWithProvider("google", safeReturnTo());
  };

  if (showOtp) {
    return (
      <AuthShell tab="register" returnTo={safeReturnTo()}>
        {error && <div className="lk-auth-error">{error}</div>}

        <h2 className="lk-auth-cardtitle">Confirme seu e-mail</h2>
        <p className="lk-auth-cardsub">Enviamos um código de 6 dígitos para {email}.</p>

        <div className="my-6 flex justify-center">
          <InputOTP
            maxLength={6}
            value={otpCode}
            onChange={setOtpCode}
            autoFocus
            autoComplete="one-time-code"
          >
            <InputOTPGroup>
              <InputOTPSlot index={0} />
              <InputOTPSlot index={1} />
              <InputOTPSlot index={2} />
              <InputOTPSlot index={3} />
              <InputOTPSlot index={4} />
              <InputOTPSlot index={5} />
            </InputOTPGroup>
          </InputOTP>
        </div>

        <button
          type="button"
          className="lk-auth-submit"
          onClick={handleVerify}
          disabled={loading || otpCode.length < 6}
        >
          {loading ? (
            <Loader2 className="h-5 w-5 animate-spin" aria-hidden="true" />
          ) : (
            <>
              Confirmar <ArrowRight size={18} strokeWidth={2} />
            </>
          )}
        </button>

        <p className="lk-auth-foot">
          Não recebeu o código?{" "}
          <button type="button" onClick={handleResend} className="lk-auth-mini">
            Reenviar
          </button>
        </p>
      </AuthShell>
    );
  }

  return (
    <AuthShell tab="register" returnTo={safeReturnTo()}>
      {error && <div className="lk-auth-error">{error}</div>}

      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label htmlFor="email" className="lk-auth-label">
            E-mail
          </label>
          <input
            id="email"
            type="email"
            autoComplete="email"
            autoFocus
            className="lk-auth-input"
            placeholder="voce@email.com"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
          />
        </div>

        <div>
          <label htmlFor="password" className="lk-auth-label">
            Senha
          </label>
          <input
            id="password"
            type="password"
            autoComplete="new-password"
            className="lk-auth-input"
            placeholder="Pelo menos 6 caracteres"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
          />
        </div>

        <div>
          <label htmlFor="confirm" className="lk-auth-label">
            Confirmar senha
          </label>
          <input
            id="confirm"
            type="password"
            autoComplete="new-password"
            className="lk-auth-input"
            placeholder="Repita a senha"
            value={confirmPassword}
            onChange={(e) => setConfirmPassword(e.target.value)}
            required
          />
        </div>

        <button type="submit" className="lk-auth-submit" disabled={loading}>
          {loading ? (
            <Loader2 className="h-5 w-5 animate-spin" aria-hidden="true" />
          ) : (
            <>
              Criar conta <ArrowRight size={18} strokeWidth={2} />
            </>
          )}
        </button>
      </form>

      <div className="lk-auth-divider">ou</div>

      <button type="button" className="lk-auth-google" onClick={handleGoogle}>
        <GoogleIcon className="h-5 w-5" /> Criar conta com Google
      </button>
    </AuthShell>
  );
}