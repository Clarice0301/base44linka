import React, { useState } from "react";
import { Save } from "lucide-react";
import { ScreenTitle } from "@/components/linka/primitives";
import { useLinka } from "@/context/LinkaContext";
import { WEIGHT_KEYS } from "@/lib/linka/match";

const AREAS = ["Tecnologia", "Dados", "Marketing digital", "Vendas", "Finanças", "Administração", "Atendimento", "Design", "Educação", "Logística", "RH"];
const LEVELS = ["Estágio", "Júnior", "Pleno", "Sênior"];
const MODELS = ["Todas", "Remoto", "Híbrido", "Presencial"];
const CONTRACTS = ["Todas", "CLT", "PJ", "Estágio", "Temporário"];
const BENEFITS = ["Vale-refeição", "Plano de saúde", "Home office", "Horário flexível", "Vale-transporte", "Bônus"];
const VALUES = ["Colaboração", "Inovação", "Estabilidade", "Propósito", "Autonomia", "Diversidade"];
const SIZES = ["Pequena", "Média", "Grande"];
const LANGUAGES = ["Português", "Inglês", "Espanhol"];
const DEALBREAKERS = ["Remoto", "Híbrido", "Presencial", "CLT", "PJ", "Estágio", "Temporário"];
const AVAILABILITY = ["Imediata", "Em até 15 dias", "Em até 30 dias", "A combinar"];

function Chips({ options, value, onChange, label }) {
  const toggle = (option) => {
    onChange(value.includes(option) ? value.filter((item) => item !== option) : [...value, option]);
  };
  return (
    <div>
      <p className="lk-eyebrow">{label}</p>
      <div className="lk-pills mt-2">
        {options.map((option) => (
          <button
            key={option}
            type="button"
            className={`lk-pill${value.includes(option) ? " is-on" : ""}`}
            onClick={() => toggle(option)}
            aria-pressed={value.includes(option)}
          >
            {option}
          </button>
        ))}
      </div>
    </div>
  );
}

export default function Preferencias() {
  const { preferences, savePreferences, notify } = useLinka();
  const [form, setForm] = useState({
    roles: preferences?.roles || [],
    areas: preferences?.areas || [],
    level: preferences?.level || "",
    salary_min: preferences?.salary_min || "",
    salary_ideal: preferences?.salary_ideal || "",
    work_model: preferences?.work_model || "Todas",
    city: preferences?.city || "",
    radius: preferences?.radius || "",
    contract: preferences?.contract || "Todas",
    availability: preferences?.availability || "",
    benefits: preferences?.benefits || [],
    values: preferences?.values || [],
    company_size: preferences?.company_size || "",
    languages: preferences?.languages || [],
    dealbreakers: preferences?.dealbreakers || [],
    weights: preferences?.weights || { skills: 3, experience: 2, salary: 3, location: 3, culture: 2, courses: 2 },
  });
  const [saving, setSaving] = useState(false);
  const set = (field, value) => setForm((prev) => ({ ...prev, [field]: value }));

  const save = async () => {
    setSaving(true);
    try {
      await savePreferences({ ...(preferences || {}), ...form, salary_min: Number(form.salary_min) || 0, salary_ideal: Number(form.salary_ideal) || 0 });
      notify("Preferências salvas.", "As vagas já aparecem reordenadas com o seu match novo.");
    } finally {
      setSaving(false);
    }
  };

  return (
    <div>
      <ScreenTitle
        title="O que eu busco"
        subtitle="Edite quando quiser: o match das vagas é recalculado na hora com esses critérios."
      />

      <div className="lk-card space-y-4">
        <div>
          <p className="lk-eyebrow">Cargos desejados</p>
          <input
            className="lk-input mt-2"
            placeholder="Ex.: analista, desenvolvedor, assistente"
            value={form.roles.join(", ")}
            onChange={(event) => set("roles", event.target.value.split(",").map((item) => item.trim()).filter(Boolean))}
            aria-label="Cargos desejados"
          />
        </div>

        <Chips label="Áreas de interesse" options={AREAS} value={form.areas} onChange={(value) => set("areas", value)} />

        <div className="grid grid-cols-2 gap-2">
          <div>
            <p className="lk-eyebrow">Nível</p>
            <select className="lk-input mt-2" value={form.level} onChange={(event) => set("level", event.target.value)} aria-label="Nível">
              <option value="">Qualquer</option>
              {LEVELS.map((item) => (
                <option key={item}>{item}</option>
              ))}
            </select>
          </div>
          <div>
            <p className="lk-eyebrow">Modelo</p>
            <select className="lk-input mt-2" value={form.work_model} onChange={(event) => set("work_model", event.target.value)} aria-label="Modelo de trabalho">
              {MODELS.map((item) => (
                <option key={item}>{item}</option>
              ))}
            </select>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-2">
          <div>
            <p className="lk-eyebrow">Salário mínimo (R$)</p>
            <input type="number" className="lk-input mt-2" placeholder="3000" value={form.salary_min} onChange={(event) => set("salary_min", event.target.value)} aria-label="Salário mínimo" />
          </div>
          <div>
            <p className="lk-eyebrow">Salário ideal (R$)</p>
            <input type="number" className="lk-input mt-2" placeholder="5000" value={form.salary_ideal} onChange={(event) => set("salary_ideal", event.target.value)} aria-label="Salário ideal" />
          </div>
        </div>

        <div className="grid grid-cols-2 gap-2">
          <div>
            <p className="lk-eyebrow">Cidade</p>
            <input className="lk-input mt-2" placeholder="São Paulo" value={form.city} onChange={(event) => set("city", event.target.value)} aria-label="Cidade" />
          </div>
          <div>
            <p className="lk-eyebrow">Raio de deslocamento</p>
            <select className="lk-input mt-2" value={form.radius} onChange={(event) => set("radius", event.target.value)} aria-label="Raio">
              <option value="">Indiferente</option>
              <option>Até 10 km</option>
              <option>Até 30 km</option>
              <option>Até 50 km</option>
            </select>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-2">
          <div>
            <p className="lk-eyebrow">Tipo de contrato</p>
            <select className="lk-input mt-2" value={form.contract} onChange={(event) => set("contract", event.target.value)} aria-label="Contrato">
              {CONTRACTS.map((item) => (
                <option key={item}>{item}</option>
              ))}
            </select>
          </div>
          <div>
            <p className="lk-eyebrow">Disponibilidade</p>
            <select className="lk-input mt-2" value={form.availability} onChange={(event) => set("availability", event.target.value)} aria-label="Disponibilidade">
              <option value="">Selecione</option>
              {AVAILABILITY.map((item) => (
                <option key={item}>{item}</option>
              ))}
            </select>
          </div>
        </div>

        <Chips label="Benefícios importantes" options={BENEFITS} value={form.benefits} onChange={(value) => set("benefits", value)} />
        <Chips label="Valores e cultura" options={VALUES} value={form.values} onChange={(value) => set("values", value)} />

        <div className="grid grid-cols-2 gap-2">
          <div>
            <p className="lk-eyebrow">Tamanho da empresa</p>
            <select className="lk-input mt-2" value={form.company_size} onChange={(event) => set("company_size", event.target.value)} aria-label="Tamanho da empresa">
              <option value="">Qualquer</option>
              {SIZES.map((item) => (
                <option key={item}>{item}</option>
              ))}
            </select>
          </div>
          <div>
            <p className="lk-eyebrow">Idiomas</p>
            <select className="lk-input mt-2" value={form.languages[0] || ""} onChange={(event) => set("languages", event.target.value ? [event.target.value] : [])} aria-label="Idiomas">
              <option value="">Qualquer</option>
              {LANGUAGES.map((item) => (
                <option key={item}>{item}</option>
              ))}
            </select>
          </div>
        </div>

        <Chips label="O que eu não aceito (critérios eliminatórios)" options={DEALBREAKERS} value={form.dealbreakers} onChange={(value) => set("dealbreakers", value)} />
      </div>

      <div className="lk-card mt-4">
        <p className="lk-eyebrow">Importância de cada fator no match</p>
        <div className="mt-3 space-y-3">
          {WEIGHT_KEYS.map(([key, label]) => (
            <div key={key}>
              <div className="flex items-center justify-between">
                <span style={{ fontSize: 13.5, color: "var(--ink)" }}>{label}</span>
                <span className="lk-num">{form.weights[key] || 1}/5</span>
              </div>
              <input
                type="range"
                min="1"
                max="5"
                value={form.weights[key] || 1}
                onChange={(event) => set("weights", { ...form.weights, [key]: Number(event.target.value) })}
                className="w-full mt-1"
                aria-label={`Importância: ${label}`}
              />
            </div>
          ))}
        </div>
      </div>

      <button type="button" className="lk-btn lk-btn-primary mt-4" onClick={save} disabled={saving}>
        <Save size={17} strokeWidth={2} /> {saving ? "Salvando..." : "Salvar preferências"}
      </button>
    </div>
  );
}