const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React, { useState } from "react";
import { Link } from "react-router-dom";
import { ArrowRight, Loader2 } from "lucide-react";

import AuthShell from "@/components/linka/AuthShell";
import GoogleIcon from "@/components/GoogleIcon";
import { safeReturnTo } from "@/lib/authReturnTo";

export default function Login() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  // Post-login destination (e.g. the MCP OAuth consent page sends users here
  // with returnTo so the grant flow can resume). Same-origin paths only.
  const returnTo = safeReturnTo();

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");
    setLoading(true);
    try {
      await db.auth.loginViaEmailPassword(email, password);
      window.location.href = returnTo;
    } catch (err) {
      setError(err.message || "E-mail ou senha inválidos");
    } finally {
      setLoading(false);
    }
  };

  const handleGoogle = () => {
    db.auth.loginWithProvider("google", returnTo);
  };

  return (
    <AuthShell tab="login" returnTo={returnTo}>
      {error && <div className="lk-auth-error">{error}</div>}

      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label htmlFor="email" className="lk-auth-label">
            E-mail
          </label>
          <input
            id="email"
            type="email"
            autoComplete="email"
            autoFocus
            className="lk-auth-input"
            placeholder="voce@email.com"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
          />
        </div>

        <div>
          <div className="mb-2 flex items-center justify-between">
            <label htmlFor="password" className="lk-auth-label is-tight">
              Senha
            </label>
            <Link to="/forgot-password" className="lk-auth-mini">
              Esqueci minha senha
            </Link>
          </div>
          <input
            id="password"
            type="password"
            autoComplete="current-password"
            className="lk-auth-input"
            placeholder="Pelo menos 6 caracteres"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
          />
        </div>

        <button type="submit" className="lk-auth-submit" disabled={loading}>
          {loading ? (
            <Loader2 className="h-5 w-5 animate-spin" aria-hidden="true" />
          ) : (
            <>
              Acessar <ArrowRight size={18} strokeWidth={2} />
            </>
          )}
        </button>
      </form>

      <div className="lk-auth-divider">ou</div>

      <button type="button" className="lk-auth-google" onClick={handleGoogle}>
        <GoogleIcon className="h-5 w-5" /> Entrar com Google
      </button>

      <div className="lk-auth-portal">
        <strong>É empresa e vai contratar?</strong>
        <p>Publique vagas, acompanhe candidaturas e conte novidades da sua empresa no Linka.</p>
        <Link to="/empresa/login">Entrar na área da empresa</Link>
      </div>
    </AuthShell>
  );
}