import React, { useState } from "react";
import { Link } from "react-router-dom";
import { ArrowLeft, Send, UserRound } from "lucide-react";
import { Chip, EmptyState, IconBox } from "@/components/linka/primitives";
import StageTrack from "@/components/linka/StageTrack";
import RecruiterPanel from "@/components/linka/RecruiterPanel";
import { useLinka } from "@/context/LinkaContext";
import { STAGES } from "@/lib/linka/data";

export default function Recrutador() {
  const { jobs, applications, profile, advanceStage, sendMessage, matchFor } = useLinka();
  const [jobId, setJobId] = useState(jobs[0]?.id || null);
  const [replyTo, setReplyTo] = useState(null);
  const [reply, setReply] = useState("");

  const activeJob = jobs.find((job) => job.id === jobId) || jobs[0] || null;
  const candidates = activeJob ? applications.filter((item) => item.jobId === activeJob.id) : [];
  const candidateName = profile.name || "Você";

  const submitReply = (applicationId) => {
    sendMessage(applicationId, reply, "company");
    setReply("");
    setReplyTo(null);
  };

  return (
    <div>
      <div className="flex items-center gap-2">
        <Link to="/perfil" className="lk-heart" aria-label="Voltar para o perfil">
          <ArrowLeft size={18} strokeWidth={2} />
        </Link>
        <div>
          <h1 className="lk-h1">Visão do recrutador</h1>
          <p className="lk-sub">Veja quem se candidatou e devolva um retorno para cada pessoa.</p>
        </div>
      </div>

      <RecruiterPanel />

      <div className="lk-pills mt-4">
        {jobs.map((job) => (
          <button
            key={job.id}
            type="button"
            className={`lk-pill${activeJob?.id === job.id ? " is-on" : ""}`}
            onClick={() => setJobId(job.id)}
            aria-pressed={activeJob?.id === job.id}
          >
            {job.title}
          </button>
        ))}
      </div>

      {activeJob ? (
        <section className="lk-card mt-4">
          <div className="flex items-start gap-3">
            <IconBox icon={activeJob.icon} accent={activeJob.accent} />
            <div className="min-w-0 flex-1">
              <h2 className="lk-card-title">{activeJob.title}</h2>
              <p className="lk-card-sub">
                {activeJob.company} · {activeJob.salary_label}
              </p>
            </div>
          </div>
          <div className="mt-3 flex flex-wrap gap-2">
            <Chip tone="blue">{activeJob.work_model}</Chip>
            <Chip tone="teal">{candidates.length} candidatura(s)</Chip>
          </div>
        </section>
      ) : null}

      <div className="mt-4 space-y-3">
        {!candidates.length ? (
          <EmptyState
            icon={UserRound}
            title="Ninguém se candidatou ainda"
            text="Assim que alguém se candidatar a esta vaga, o perfil aparece aqui com a etapa atual."
          />
        ) : null}

        {candidates.map((application) => (
          <article key={application.id} className="lk-card">
            <div className="flex items-start gap-3">
              <span
                className="grid place-items-center"
                style={{
                  width: 44,
                  height: 44,
                  borderRadius: 999,
                  background: "var(--tint-blue)",
                  color: "var(--ink)",
                  fontWeight: 600,
                }}
              >
                {candidateName.charAt(0).toUpperCase()}
              </span>
              <div className="min-w-0 flex-1">
                <h3 className="lk-card-title">{candidateName}</h3>
                <p className="lk-card-sub">{profile.headline}</p>
              </div>
              <Chip tone="sun">{matchFor(activeJob)}% de match</Chip>
            </div>

            <div className="mt-3 flex flex-wrap gap-2">
              {profile.skills.slice(0, 5).map((skill) => (
                <Chip key={skill} tone="teal">
                  {skill}
                </Chip>
              ))}
            </div>

            {application.message ? (
              <p className="lk-sub" style={{ marginTop: 12 }}>
                “{application.message}”
              </p>
            ) : null}

            <StageTrack stage={application.stage} />

            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                className="lk-btn lk-btn-primary lk-btn-sm"
                disabled={application.stage >= 3}
                onClick={() => advanceStage(application.id)}
              >
                {application.stage >= 3 ? "Processo encerrado" : `Avançar para ${STAGES[application.stage + 1]}`}
              </button>
              <button
                type="button"
                className="lk-btn lk-btn-soft lk-btn-sm"
                onClick={() => setReplyTo(replyTo === application.id ? null : application.id)}
              >
                <Send size={16} strokeWidth={1.8} /> Responder
              </button>
            </div>

            {replyTo === application.id ? (
              <div className="mt-2">
                <textarea
                  className="lk-textarea"
                  placeholder="Escreva um retorno gentil e claro para essa pessoa."
                  value={reply}
                  onChange={(event) => setReply(event.target.value)}
                  aria-label="Resposta do recrutador"
                />
                <button
                  type="button"
                  className="lk-btn lk-btn-primary lk-btn-sm mt-2"
                  onClick={() => submitReply(application.id)}
                >
                  Enviar resposta
                </button>
              </div>
            ) : null}
          </article>
        ))}
      </div>
    </div>
  );
}