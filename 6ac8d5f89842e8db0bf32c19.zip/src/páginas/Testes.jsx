import React, { useState } from "react";
import { ClipboardList, RotateCcw, Trophy } from "lucide-react";
import { Chip, EmptyState, ProgressBar, ScreenTitle } from "@/components/linka/primitives";
import { LEVEL_LABELS, RETRY_DAYS, TESTS, levelFor } from "@/lib/linka/tests";
import { useLinka } from "@/context/LinkaContext";

const STORE_KEY = "lk-test-results";

function readResults() {
  try {
    return JSON.parse(localStorage.getItem(STORE_KEY)) || {};
  } catch {
    return {};
  }
}

function shuffle(list) {
  const copy = [...list];
  for (let i = copy.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [copy[i], copy[j]] = [copy[j], copy[i]];
  }
  return copy;
}

function daysLeft(lastIso) {
  const next = new Date(lastIso).getTime() + RETRY_DAYS * 24 * 60 * 60 * 1000;
  return Math.max(0, Math.ceil((next - Date.now()) / (24 * 60 * 60 * 1000)));
}

export default function Testes() {
  const { profile, updateProfile, notify } = useLinka();
  const [results, setResults] = useState(readResults);
  const [run, setRun] = useState(null);
  const [index, setIndex] = useState(0);
  const [answers, setAnswers] = useState([]);
  const [done, setDone] = useState(null);

  const start = (test) => {
    setRun({ test, sample: shuffle(test.bank).slice(0, test.count) });
    setIndex(0);
    setAnswers([]);
    setDone(null);
  };

  const finish = (runData, finalAnswers) => {
    const score = runData.sample.reduce((sum, q, i) => sum + (finalAnswers[i] === q.a ? 1 : 0), 0);
    const level = levelFor(score);
    const prev = results[runData.test.id] || {};
    const entry = { score, level, at: new Date().toISOString() };
    const updated = {
      ...results,
      [runData.test.id]: {
        best: Math.max(prev.best || 0, score),
        bestLevel: Math.max(prev.bestLevel || 0, level),
        history: [...(prev.history || []), entry].slice(-10),
        last: entry.at,
      },
    };
    setResults(updated);
    localStorage.setItem(STORE_KEY, JSON.stringify(updated));
    setDone({ score, level });
    if (level >= 2) {
      updateProfile({ validated: { ...(profile.validated || {}), [runData.test.skill]: level } });
      notify("Habilidade validada!", `${runData.test.skill} — nível ${level} (${LEVEL_LABELS[level]}).`);
    }
  };

  const answer = (option) => {
    const next = [...answers, option];
    setAnswers(next);
    if (index + 1 >= run.sample.length) finish(run, next);
    else setIndex(index + 1);
  };

  if (done && run) {
    const test = run.test;
    return (
      <div>
        <div className="lk-card" style={{ textAlign: "center" }}>
          <span
            className="grid place-items-center"
            style={{ width: 56, height: 56, margin: "0 auto 12px", borderRadius: 18, background: "var(--tint-teal)", color: "var(--teal-ink)" }}
          >
            <Trophy size={26} strokeWidth={1.8} />
          </span>
          <h2 className="lk-card-title" style={{ fontSize: 18 }}>
            {done.score} de {run.sample.length} corretas
          </h2>
          <Chip tone="teal">
            Nível {done.level} · {LEVEL_LABELS[done.level]}
          </Chip>
          <p className="lk-card-sub mt-3">
            {done.level >= 2
              ? `Habilidade "${test.skill}" validada no seu perfil. O melhor resultado fica guardado.`
              : "Refira-se ao material e tente de novo em alguns dias — o teste fica disponível novamente em 7 dias."}
          </p>
        </div>

        <section className="mt-4">
          <p className="lk-eyebrow">Explicações das respostas</p>
          <div className="mt-3 space-y-2">
            {run.sample.map((q, i) => {
              const correct = answers[i] === q.a;
              return (
                <div key={q.q} className="lk-card">
                  <strong style={{ fontSize: 14, color: "var(--ink)" }}>
                    {correct ? "✓" : "✗"} {q.q}
                  </strong>
                  <p className="lk-card-sub mt-1">
                    Resposta correta: <strong>{q.o[q.a]}</strong> — {q.e}
                  </p>
                  {!correct ? (
                    <p className="lk-card-sub">Sua resposta: {q.o[answers[i]]}</p>
                  ) : null}
                </div>
              );
            })}
          </div>
        </section>

        <button type="button" className="lk-btn lk-btn-soft mt-4" onClick={() => setRun(null)}>
          Voltar aos testes
        </button>
      </div>
    );
  }

  if (run) {
    const question = run.sample[index];
    return (
      <div>
        <ScreenTitle title={run.test.title} subtitle={`Questão ${index + 1} de ${run.sample.length}`} />
        <ProgressBar value={Math.round((index / run.sample.length) * 100)} />
        <div className="lk-card mt-4">
          <strong style={{ fontSize: 15.5, color: "var(--ink)", lineHeight: 1.4, display: "block" }}>{question.q}</strong>
          <div className="mt-3 space-y-2">
            {question.o.map((option, oi) => (
              <button
                key={option}
                type="button"
                className="lk-btn lk-btn-soft lk-btn-sm"
                style={{ justifyContent: "flex-start", textAlign: "left" }}
                onClick={() => answer(oi)}
              >
                {option}
              </button>
            ))}
          </div>
        </div>
        <button type="button" className="lk-btn lk-btn-sm mt-3" style={{ color: "var(--ink-2)" }} onClick={() => setRun(null)}>
          Sair do teste
        </button>
      </div>
    );
  }

  return (
    <div>
      <ScreenTitle
        title="Testes de habilidades"
        subtitle="Resultados opcionais: valide habilidades com nível de 1 a 4. Nenhum teste elimina um candidato sozinho."
      />

      <div className="lk-card mt-1">
        <ClipboardList size={18} strokeWidth={1.8} style={{ color: "var(--teal-ink)" }} />
        <p className="lk-card-sub mt-2">
          Cada aplicação sorteia 15 questões com explicação ao final. O melhor resultado fica no seu
          histórico e você pode refazer após 7 dias.
        </p>
      </div>

      <div className="mt-4 space-y-3">
        {TESTS.map((test) => {
          const result = results[test.id];
          const cooldown = result?.last ? daysLeft(result.last) : 0;
          return (
            <div key={test.id} className="lk-card">
              <div className="flex items-start justify-between gap-3">
                <div className="min-w-0">
                  <h3 className="lk-card-title">{test.title}</h3>
                  <p className="lk-card-sub">
                    {test.count} questões · habilidade: {test.skill}
                  </p>
                </div>
                {result ? (
                  <Chip tone="teal">
                    Melhor: {result.best}/{test.count} · nível {result.bestLevel}
                  </Chip>
                ) : null}
              </div>
              {test.demo ? (
                <p className="lk-card-sub mt-2" style={{ fontSize: 12.5 }}>
                  Aviso: este teste de demonstração não substitui avaliação psicológica.
                </p>
              ) : null}
              {result?.history?.length ? (
                <p className="lk-card-sub mt-1" style={{ fontSize: 12.5 }}>
                  Histórico: {result.history.map((h) => `${h.score}/${test.count}`).join(" · ")}
                </p>
              ) : null}
              {cooldown ? (
                <button type="button" className="lk-btn lk-btn-soft lk-btn-sm mt-3" disabled>
                  Refazer disponível em {cooldown} dia(s)
                </button>
              ) : (
                <button
                  type="button"
                  className={`lk-btn lk-btn-sm mt-3 ${result ? "lk-btn-soft" : "lk-btn-primary"}`}
                  onClick={() => start(test)}
                >
                  {result ? <RotateCcw size={15} strokeWidth={1.8} /> : null}
                  {result ? "Refazer teste" : "Fazer teste"}
                </button>
              )}
            </div>
          );
        })}
      </div>

      <EmptyState
        icon={ClipboardList}
        title="Dica"
        text="Habilidades validadas por teste pesam mais no seu match com as vagas."
      />
    </div>
  );
}