const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { ArrowLeft, Building2, Trash2, UserRound, Users } from "lucide-react";

import { useLinka } from "@/context/LinkaContext";
import { Chip, IconBox } from "@/components/linka/primitives";
import JobPostForm from "@/components/linka/company/JobPostForm";
import CompanyNews from "@/components/linka/company/CompanyNews";

export default function GestaoEmpresa() {
  const { notify } = useLinka();
  const [company, setCompany] = useState(null);
  const [jobs, setJobs] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let alive = true;
    (async () => {
      const me = await db.auth.me();
      const [companyPage, jobPage] = await Promise.all([
        db.entities.Company.filter({ created_by_id: me.id }, { limit: 1 }),
        db.entities.Job.filter({ created_by_id: me.id }, { sort: "-created_date", limit: 20 }),
      ]);
      if (!alive) return;
      setCompany(companyPage.items?.[0] || null);
      setJobs(jobPage.items || []);
      setLoading(false);
    })();
    return () => {
      alive = false;
    };
  }, []);

  const companyName = company?.name || "Minha empresa";

  const removeJob = async (job) => {
    await db.entities.Job.delete(job.id);
    setJobs((prev) => prev.filter((item) => item.id !== job.id));
    notify("Vaga removida.", job.title);
  };

  return (
    <div>
      <div className="flex items-center gap-2">
        <Link to="/perfil" className="lk-heart" aria-label="Voltar para o perfil">
          <ArrowLeft size={18} strokeWidth={2} />
        </Link>
        <div>
          <h1 className="lk-h1">Gestão da empresa</h1>
          <p className="lk-sub">Lance vagas, publique novidades e acompanhe as candidaturas.</p>
        </div>
      </div>

      <div className="mt-3 flex flex-wrap gap-2">
        <Chip tone="blue">
          <Building2 size={13} strokeWidth={2} /> {companyName}
        </Chip>
        <Chip tone="teal">{jobs.length} vaga(s) publicada(s)</Chip>
      </div>

      <div className="mt-4 grid grid-cols-2 gap-2.5">
        <Link to="/empresa" className="lk-card">
          <strong style={{ display: "block", fontSize: 14, color: "var(--ink)" }}>Minha empresa</strong>
          <p className="lk-card-sub">Logo, descrição e dados.</p>
        </Link>
        <Link to="/recrutador" className="lk-card">
          <strong style={{ display: "block", fontSize: 14, color: "var(--ink)" }}>Candidaturas</strong>
          <p className="lk-card-sub">Quem se candidatou e retorno.</p>
        </Link>
      </div>

      <section className="mt-6">
        <div className="flex items-center justify-between">
          <p className="lk-eyebrow">Vagas da empresa</p>
          <Users size={16} strokeWidth={1.8} style={{ color: "var(--ink-2)" }} />
        </div>

        <div className="mt-3 space-y-2">
          <JobPostForm
            companyName={companyName}
            onPosted={(job) => {
              setJobs((prev) => [job, ...prev]);
              notify("Vaga publicada.", `${job.title} já está na lista de vagas da rede.`);
            }}
          />

          {loading ? <p className="lk-sub">Carregando suas vagas...</p> : null}

          {!loading && !jobs.length ? (
            <div className="lk-card">
              <p className="lk-card-sub">Nenhuma vaga publicada ainda. Use “Lançar vaga” para começar.</p>
            </div>
          ) : null}

          {jobs.map((job) => (
            <article key={job.id} className="lk-card">
              <div className="flex items-start gap-3">
                <IconBox icon={job.icon || "briefcase"} accent={job.accent || "blue"} />
                <div className="min-w-0 flex-1">
                  <h3 className="lk-card-title">{job.title}</h3>
                  <p className="lk-card-sub">
                    {job.work_model} · {job.salary_label}
                  </p>
                </div>
                <button type="button" className="lk-heart" aria-label="Remover vaga" onClick={() => removeJob(job)}>
                  <Trash2 size={17} strokeWidth={1.8} />
                </button>
              </div>
              <div className="mt-3 flex flex-wrap gap-2">
                <Chip tone="blue">{job.level}</Chip>
                <Chip tone="teal">{job.contract}</Chip>
                {job.is_demo === false ? <Chip tone="sun">publicada por você</Chip> : null}
              </div>
            </article>
          ))}
        </div>
      </section>

      <div className="mt-6">
        <CompanyNews companyName={companyName} />
      </div>

      <section className="mt-6">
        <div className="lk-card flex items-center gap-3">
          <span
            className="grid place-items-center"
            style={{ width: 44, height: 44, borderRadius: 14, background: "var(--tint-blue)", color: "var(--ink)" }}
          >
            <UserRound size={22} strokeWidth={1.8} />
          </span>
          <div>
            <strong style={{ display: "block", fontSize: 14.5, color: "var(--ink)" }}>Cursos</strong>
            <p className="lk-card-sub">
              O catálogo de cursos do Linka é oficial e verificado, mantido pela plataforma — a empresa não publica
              cursos, mas pode indicar um curso na descrição da vaga.
            </p>
          </div>
        </div>
      </section>
    </div>
  );
}